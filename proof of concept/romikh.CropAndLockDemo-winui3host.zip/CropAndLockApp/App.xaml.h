﻿#pragma once

#include "App.xaml.g.h"

namespace winrt::CropAndLockApp::implementation
{
    struct App : AppT<App>
    {
        App();

        void OnLaunched(Microsoft::UI::Xaml::LaunchActivatedEventArgs const&);

    private:
        void InitializeCropAndLock();
        static DWORD WINAPI CropAndLockThreadProc(LPVOID);

        winrt::Microsoft::UI::Xaml::Window window{ nullptr };
        wil::unique_handle m_cropAndLockThread;
    };
}
