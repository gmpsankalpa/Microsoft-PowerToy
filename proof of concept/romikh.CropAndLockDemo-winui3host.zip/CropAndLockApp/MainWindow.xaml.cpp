﻿#include "pch.h"
#include "MainWindow.xaml.h"
#if __has_include("MainWindow.g.cpp")
#include "MainWindow.g.cpp"
#endif

#include <microsoft.ui.xaml.window.h>


using namespace winrt::Microsoft::UI::Xaml;
using namespace winrt::Microsoft::UI::Xaml::Input;
using namespace winrt::Windows::Media::Playback;
using namespace winrt::Windows::Foundation;
using namespace std::chrono_literals;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::CropAndLockApp::implementation
{
    weak_ref<MainWindow> MainWindow::s_instance{ nullptr };

    MainWindow::MainWindow()
    {
        InitializeComponent();

        auto nativeWindow = this->try_as<::IWindowNative>();
        winrt::check_bool(nativeWindow);
        winrt::check_hresult(nativeWindow->get_WindowHandle(&m_hwnd));

        Title(L"Crop and Lock - Welcome");
    }

    void MainWindow::Show()
    {
        ::ShowWindow(m_hwnd, SW_SHOW);
    }

    void MainWindow::Hide()
    {
        ::ShowWindow(m_hwnd, SW_HIDE);
    }
    void MainWindow::Exit()
    {
        ExitAsync();
    }

    winrt::fire_and_forget MainWindow::ExitAsync()
    {
        auto strong = get_strong();
        co_await wil::resume_foreground(DispatcherQueue());
        this->Close();
    }

    void MainWindow::OkButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        const auto player = IntroPlayer().MediaPlayer();
        player.Pause();
        player.Position(0s);

        Hide();
    }

    void MainWindow::ContentLoaded(IInspectable const&, RoutedEventArgs const&)
    {
        const auto dpi = GetDpiForWindow(m_hwnd);
        auto size = Content().DesiredSize();
        size.Width *= (dpi / 96.f);
        size.Height *= (dpi / 96.f);

        RECT rect = { 0, 0, static_cast<int>(size.Width), static_cast<int>(size.Height) };
        winrt::check_bool(AdjustWindowRectExForDpi(&rect, WS_OVERLAPPEDWINDOW, false, 0, dpi));
        auto adjustedWidth = rect.right - rect.left;
        auto adjustedHeight = rect.bottom - rect.top;

        SetWindowPos(m_hwnd, nullptr, 0, 0, adjustedWidth, adjustedHeight, SWP_NOMOVE | SWP_NOZORDER);

        s_instance = get_weak();
    }

    void MainWindow::MediaPlayerElement_Tapped(winrt::Windows::Foundation::IInspectable const&, winrt::Microsoft::UI::Xaml::Input::TappedRoutedEventArgs const&)
    {
        const auto player = IntroPlayer().MediaPlayer();
        const auto playbackState = player.PlaybackSession().PlaybackState();
        if (playbackState == MediaPlaybackState::Playing)
        {
            player.Pause();
        }
        else
        {
            player.Play();
        }
    }
}