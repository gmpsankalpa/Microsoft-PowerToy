﻿#pragma once

#include "MainWindow.g.h"

namespace winrt::CropAndLockApp::implementation
{
    struct MainWindow : MainWindowT<MainWindow>
    {
        MainWindow();

        void Show();
        void Hide();
        void Exit();
        winrt::fire_and_forget ExitAsync();

        void OkButton_Click(Windows::Foundation::IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void ContentLoaded(Windows::Foundation::IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void MediaPlayerElement_Tapped(winrt::Windows::Foundation::IInspectable const& sender, winrt::Microsoft::UI::Xaml::Input::TappedRoutedEventArgs const& e);

        static winrt::CropAndLockApp::MainWindow TryGetInstance() 
        { 
            if (auto strong = s_instance.get())
            {
                return *strong;
            }
            else
            {
                return nullptr;
            }
        }

    private:
        static weak_ref<MainWindow> s_instance;
        HWND m_hwnd{ nullptr };
    };
}

namespace winrt::CropAndLockApp::factory_implementation
{
    struct MainWindow : MainWindowT<MainWindow, implementation::MainWindow>
    {
    };
}
